const jwt = require('jsonwebtoken');

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Access token required' });

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.status(401).json({ error: 'Invalid or expired token' });
    req.user = user;
    next();
  });
}

function requireAdmin(req, res, next) {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

function requireClientOrAdmin(req, res, next) {
  if (req.user.role !== 'admin' && req.user.role !== 'client') {
    return res.status(403).json({ error: 'Authentication required' });
  }
  next();
}

module.exports = { authenticateToken, requireAdmin, requireClientOrAdmin };
